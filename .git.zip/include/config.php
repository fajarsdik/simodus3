<?php
    $host = "localhost";
    $username = "simodusc";
    $password = "4MbY68h5xz";
    $database = "simodusc_simodus";
    $config = mysqli_connect($host, $username, $password, $database);

    if(!$config){
        die("Koneksi database gagal: " . mysqli_connect_error());
    }
?>
